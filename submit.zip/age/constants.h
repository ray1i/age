#ifndef _CONSTANTS_H_
#define _CONSTANTS_H_

#define ROWS 22
#define COLUMNS 80
#define MAXTICKSOFFSCREEN 10
#define TICKLENGTH 50

#endif
