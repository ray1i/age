#ifndef _MOVEMENT_H_
#define _MOVEMENT_H_


struct Movement {
    float slopeX, slopeY;
};

#endif
