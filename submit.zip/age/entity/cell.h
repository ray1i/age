#ifndef _CELL_H_
#define _CELL_H_

struct Cell {
    int x, y;
    char sprite;
};

#endif
