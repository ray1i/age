#ifndef _BORDER_H_
#define _BORDER_H_

enum BorderDirection { NORTH, EAST, SOUTH, WEST };

#endif
