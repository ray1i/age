#ifndef __ARLG_ACTIONS_H
#define __ARLG_ACTIONS_H

enum Action {
    INVALID = 0,
    MOVE_LEFT,
    MOVE_RIGHT,
};

#endif
