#ifndef __JUNK_ACTIONS_H
#define __JUNK_ACTIONS_H

enum Action {
    INVALID=0,
    MOVE_UP,
    MOVE_LEFT,
    MOVE_RIGHT,
};

#endif
